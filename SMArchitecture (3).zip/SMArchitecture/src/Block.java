
public class Block {

	int validBit;
	int tag;
	String data;
	
}
