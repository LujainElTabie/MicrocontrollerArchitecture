# SMArchitecture
Simple microcontroller architecture written in java
